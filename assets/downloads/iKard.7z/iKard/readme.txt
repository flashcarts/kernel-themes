++++++++++++++++++++++++++++++++++++
        iKard Skin by axlace
++++++++++++++++++++++++++++++++++++

Based on Black skin included in firmware v4.06

Please feel free to distribute skin so long as this text file is included

Copy iKard folder to your AceKard RPG under %drive%:\__rpg\ui

Tools Used:

IrfanView
Photoshop CS3
AKRPG Skin Editor v4.06

Contact: part_time_economist@hotmail.com

**contents scanned with Symantec Corporate Edition (defs. 12/1/2008)

v1.0 - initial release
v1.1 - fixed calendar days/headings
v1.2 - fixed start menu and selection highlight