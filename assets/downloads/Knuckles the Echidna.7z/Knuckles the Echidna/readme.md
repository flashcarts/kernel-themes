# Knuckles the Echidna

**Author:** Biochao       
**Release Date:** December 7th, 2009

## Additional Features

- **Custom Font:** No
- **TWiLightMenu++ Enhanced:** No
