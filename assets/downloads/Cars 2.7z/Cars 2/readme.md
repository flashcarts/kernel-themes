# Cars 2

**Author:** Chadrcheze       
**Release Date:** August 5th, 2011

## Additional Features

- **Custom Font:** No
- **TWiLightMenu++ Enhanced:** No