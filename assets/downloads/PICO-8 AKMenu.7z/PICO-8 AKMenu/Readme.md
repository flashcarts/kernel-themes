**Skin title:** PICO-8
**Author:** Vulpes-Vulpeos, backported to WoodR4/AKMenu by Sanras
**Released:** 20.03.2019
**Made for:** AKMenu
**Custom font:** Yes
**Screenshots:**
![preview](https://github.com/DS-Homebrew/twlmenu-extras/raw/master/_nds/TWiLightMenu/akmenu/themes/PICO-8/Preview.jpg)
**Additional credits:** PICO-8 belongs to Lexaloffle Games. More info here: https://www.lexaloffle.com/pico-8.php

---

**Install Instructions:**

1. Copy the `PICO-8 AKMenu` folder to your kernel's `ui` folder. This is `/__rpg/ui/` on WoodR4 kernels, and `/__aio/ui/` on AKAIO.

2. Copy `pico-8.pcf` from `Theme_Data` to your kernel's fonts folder. This is `/__rpg/fonts/` on WoodR4 kernels, and `/__aio/fonts/` on AKAIO.

3. Copy the `PICO-English` folder from `Theme_Data` to your kernel's language folder. This is `/__rpg/language/` on WoodR4 kernels, and `/__aio/language/` on AKAIO.

4. Boot up your cart, and select PICO-8 AKMenu theme. Set your language to PICO-English.