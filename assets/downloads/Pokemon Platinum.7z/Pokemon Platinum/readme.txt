Pokemon Platinum By Tony
------------------------

A skin based on the in game interfaces to make your DS look like the pokedex :) 

Credits
-------

Graphics ripped by:-
Haru Raindose
zeikku
Polursine

