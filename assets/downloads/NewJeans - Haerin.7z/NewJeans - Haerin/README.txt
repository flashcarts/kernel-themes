Thank you so much for downloading my theme! I hope you enjoy it. <3

~ freshberries