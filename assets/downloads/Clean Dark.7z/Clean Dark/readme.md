# Clean Dark

- **Author:** Von Millhausen
- **Release Date:** 11/2024

## Additional Features

- **Custom Font:** no
- **TWiLightMenu++ Enhanced:** no

## Additional Notes

- Thanks to FamFamFam/Mark James for the Silk icons used in this theme
- Thanks to Dan Taylor for the AK Skin Edit tool which was very useful
- Thanks to LizardWish for the excellent PixageFX Studio (which I used for more control over RGB555 dithering)
- Thanks to all the devs behind the "ImageMagick" software (used to bulk-convert my PNGs to the final BMP files)

## Version History

- **1.1 - 11/2024**
  - Added a frame to window title bars
  - Adjusted the bar colours of highlighted items
  - Adjusted the height of the game properties window
  - Adjusted the position of the progress bar within the progress bar window
  - Adjusted the position of the clock hour/minute separator
  - Adjusted the size and position of the Nintendo DS logo
  - Adjusted the width of the Start button
  - Fixed a graphical issue with window title bars
- **1.0 - 09/2024**
  - Initial release