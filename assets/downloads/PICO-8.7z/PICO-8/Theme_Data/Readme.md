**Skin title:** PICO-8
**Author:** Vulpes-Vulpeos, backported to WoodR4/AKMenu by Sanras
**Released:** 20.03.2019
**Made for:** AKMenu
**Custom font:** Yes
**Screenshots:**
![preview](https://github.com/DS-Homebrew/twlmenu-extras/raw/master/_nds/TWiLightMenu/akmenu/themes/PICO-8/Preview.jpg)
**Additional credits:** PICO-8 belongs to Lexaloffle Games. More info here: https://www.lexaloffle.com/pico-8.php