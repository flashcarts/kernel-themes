-------------------------------------
	  Skin Information
-------------------------------------
Rockman X theme skin for the Acekard 2 by Taylor Brown (Mirby)

Just put the folder under __aio/ui on your MicroSD card of choice!

-------------------------------------
	    Distribution
-------------------------------------
Free to use, just keep this text file with it please.

Thank you! ^.^

-------------------------------------
              Upcoming
-------------------------------------
Rockman DASH skin
Rockman ZX skin
Rockman Perfect Memories skin
Axl skin
StarTropics skin

-------------------------------------
	      Contact
-------------------------------------
Have new skin ideas? Tell me about them! E-mail me at
thekirbymazter@gmail.com

I'll do my best to make them as best I can.


