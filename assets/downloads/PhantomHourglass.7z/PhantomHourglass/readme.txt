===================
THEME BY CENTY
===================

This is my second skin for the AceKard RPG/AK2 a Zelda theme because it's original ;)

I based this skin on the Mario one by Hairzo only editing minor parts of the config files and of course most of the graphics.

Big thanks to Hairzon and philcsf for the design aids they provided they were a blessing you guys rock!

===================
CONTACT
===================
el_centy@hotmail.com
www.radio-ninty.co.uk


===================
DISTRIBUTION
===================

Feel free to share this for now but do include this readme file with it.
Once/if NDSThemes.com starts hosting AceKard themes I would prefer if the theme was only avalible there. If people want to use elements of this theme for their own then feel free just when you write your readme give credit to me as I did with Hairzo.

Have fun!



