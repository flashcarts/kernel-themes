# DS Menu

**Author:** Vulpes-Vulpeos     
**Released:** 14.01.2019     
**Made for:** TWiLightMenu++         
**Custom font:** No

![preview](https://github.com/DS-Homebrew/twlmenu-extras/raw/master/_nds/TWiLightMenu/akmenu/themes/Nintendo%20DS-Like/Preview.jpg)

**Additional features:**
You can change the color of the theme by replacing files in main theme folder from `/colors/~color name~/ folder`.      
Also you can remove additional line in calendar by renaming `upper_screen.bmp` into `upper_screen_cal6.bmp` and `upper_screen_cal5.bmp` into `upper_screen.bmp`. If month needs more lines then rename files backwards.
