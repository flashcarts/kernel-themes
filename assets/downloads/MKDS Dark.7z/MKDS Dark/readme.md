# Mario Kart DS: Dark

<p align="center">
	<img src="https://raw.githubusercontent.com/DS-Homebrew/twlmenu-extras/master/_nds/TWiLightMenu/akmenu/themes/MKDS%20Dark/screenshots/main.jpg">
	<img src="https://raw.githubusercontent.com/DS-Homebrew/twlmenu-extras/master/_nds/TWiLightMenu/akmenu/themes/MKDS%20Dark/screenshots/progress.jpg"><br>
	<img src="https://raw.githubusercontent.com/DS-Homebrew/twlmenu-extras/master/_nds/TWiLightMenu/akmenu/themes/MKDS%20Dark/screenshots/rom.jpg">
	<img src="https://raw.githubusercontent.com/DS-Homebrew/twlmenu-extras/master/_nds/TWiLightMenu/akmenu/themes/MKDS%20Dark/screenshots/start.jpg">
</p>

**Author:** amassenburg     
**Creation Date:** January 1st, 2010

## Additional Features

- **Custom Font:** No
- **TWiLightMenu++ Enhanced:** No
