# 2D Shadow the Hedgehog Artwork

Author: Biochao

Date released: December 7th 2009

Made for: AceKard

Custom font: No
