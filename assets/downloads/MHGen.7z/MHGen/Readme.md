**Skin title:** MHGen

**Author:** Vulpes-Vulpeos

**Released:** 25.01.2019

**Made for:** TWiLightMenu++

**Custom font:** No

**Screenshots:**
![preview](https://github.com/DS-Homebrew/twlmenu-extras/raw/master/_nds/TWiLightMenu/akmenu/themes/MHGen/Preview.jpg)

**Additional features:**
There are several backgrounds for top screen for every village. To change it you need to rename background file to `upper_screen.bmp` in theme folder.
