**Skin title:** The Legend of Zelda: Link’s Awakening Flying Rooster square
**Author:** Vulpes-Vulpeos
**Released:** 15.06.2019
**Made for:** TWiLightMenu++
**Custom font:** No
**Screenshots:**
**Additional features:**
Top screen is animated.
**Additional credits:** 