# Copper 
**Author:** Cannonfoddr      
**Description:** An Acekard/AKAIO skin with a 'copper' feel to it      
**Upload Date:** 31st Jan 2010

## Additional Features
**Custom Font:** No      
**TWiLightMenu++ Enhanced:** No